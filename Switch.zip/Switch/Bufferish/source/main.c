
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_emc.h"
#include "pin_mux.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#include "eGFX.h"
#include "eGFX_Driver.h"
#include "FONT_5_7_1BPP.h"
#include "OCR_A_Extended__20px__Bold__SingleBitPerPixelGridFit_1BPP.h"
#include "pin_mux.h"
#include "fsl_iocon.h"
#include "fsl_device_registers.h"
#include "fsl_i2c.h"
#include "fsl_i2s.h"
#include "fsl_wm8904.h"
#include "Audio.h"
#include "SDRAM.h"

#define SIZE 						960000             //960000 for 30 seconds
#define IDLE1						0
#define REC							1
#define IDLE2						2
#define PLAYBACK					3

#define PORT_INPUT 					4				//PIO19 is Port 4
#define PIN_INPUT  					4				//PIO19 is Pin 4
#define PULLUP_MODE					(0x2<<4)		//Use internal pull-up resistor

volatile uint32_t NextSampleOut = 0;       //CODEC send through
volatile uint32_t MonoL = 0;
volatile uint32_t MonoR = 0;
volatile uint32_t DelayTicker = 0;         //delay function variable


volatile uint32_t Mode = 0;			// mode variable
volatile uint32_t Index = 0;       // Record tracking
volatile uint32_t PBIndex = 0;     // Play back tracking
volatile uint32_t Switch = 0;	   // Foot switch variable


/*
	This union will be used to split 32-bit FIFO data into 2 int16_t samples.
*/
typedef union
{
	uint32_t Data;
	int16_t Channel[2];

}I2S_FIFO_Data_t;

/***
 *      ___ ____  ____    _______  __  ___       _                             _
 *     |_ _|___ \/ ___|  |_   _\ \/ / |_ _|_ __ | |_ ___ _ __ _ __ _   _ _ __ | |_
 *      | |  __) \___ \    | |  \  /   | || '_ \| __/ _ \ '__| '__| | | | '_ \| __|
 *      | | / __/ ___) |   | |  /  \   | || | | | ||  __/ |  | |  | |_| | |_) | |_
 *     |___|_____|____/    |_| /_/\_\ |___|_| |_|\__\___|_|  |_|   \__,_| .__/ \__|
 *                                                                      |_|
 */

void FLEXCOMM6_DriverIRQHandler(void)
{
    if (I2S0->FIFOINTSTAT & I2S_FIFOINTSTAT_TXLVL_MASK)
    {
        	  /*
					NextSampleOut Holds the last value from the I2S RX Interrupt.
				  It is also ready in the "packed" FIFO format
			  */

				if(Mode == PLAYBACK)
					{
					I2S0->FIFOWR = NextSampleOut + LoopBuffer[PBIndex];   //add buffer at offset index (first 2 sec are thrown away)
					PBIndex++;

					if(PBIndex == Index)				//loop at end of array
						{
						PBIndex = 0;
						}

					}else{
					PBIndex = 0;
					I2S0->FIFOWR = NextSampleOut;        //direct send through when not in play back
					}



				 /* Clear TX level interrupt flag */
        I2S0->FIFOSTAT = I2S_FIFOSTAT_TXLVL(1U);
		}
}

/***
 *      ___ ____  ____    ____  __  __  ___       _                             _
 *     |_ _|___ \/ ___|  |  _ \ \ \/ / |_ _|_ __ | |_ ___ _ __ _ __ _   _ _ __ | |_
 *      | |  __) \___ \  | |_) | \  /   | || '_ \| __/ _ \ '__| '__| | | | '_ \| __|
 *      | | / __/ ___) | |  _ <  /  \   | || | | | ||  __/ |  | |  | |_| | |_) | |_
 *     |___|_____|____/  |_| \_\/_/\_\ |___|_| |_|\__\___|_|  |_|   \__,_| .__/ \__|
 *                                                                       |_|
 */
void FLEXCOMM7_DriverIRQHandler(void)
{
		register float LeftChannel;
		register float RightChannel;
	    I2S_FIFO_Data_t FIFO_Data;

     /* Clear RX level interrupt flag */
     I2S1->FIFOSTAT = I2S_FIFOSTAT_RXLVL(1U);

	     /*
				Read the Receive FIFO.   Data is packed as two samples in one 32-bit word.  We will immediately store the data
				in a variable that is used is the transmit routine to send incoming data back out.
		 */
	    FIFO_Data.Data = I2S1->FIFORD;
	    NextSampleOut = FIFO_Data.Data; //dump the data back out!
	    MonoR = (NextSampleOut<<16);
	    MonoL = (MonoR>>16);
	    NextSampleOut = MonoL | MonoR;


			if(Mode == REC)									//Record mode
				{
				LoopBuffer[Index] = NextSampleOut;     //Send data to array
				Index++;

				if(Index == SIZE)
					{                 //End recording at end of array
					Mode = IDLE2;
					}

				}


	   LeftChannel = (float)(FIFO_Data.Channel[0])/32768.0f;
	   RightChannel = (float)(FIFO_Data.Channel[1])/32768.0f;


}

void SysTick_Handler()            //millisecond counter
{
	DelayTicker++;
}

void WriteToScreen()
{
	eGFX_ImagePlane_Clear(&eGFX_BackBuffer);

			eGFX_printf(&eGFX_BackBuffer,
										20,250,   //The x and y coordinate of where to draw the text.
										&FONT_5_7_1BPP,   //Long font name!
									  "[Hello World!]    Switch Test    Mode is %d",Mode);
			eGFX_printf(&eGFX_BackBuffer,
										20,200,   //The x and y coordinate of where to draw the text.
										&FONT_5_7_1BPP,   //Long font name!
									  "Index is %d",Index);
			eGFX_printf(&eGFX_BackBuffer,
										200,200,   //The x and y coordinate of where to draw the text.
										&FONT_5_7_1BPP,   //Long font name!
									  "PBIndex is %d",PBIndex);
			eGFX_printf(&eGFX_BackBuffer,
										20,150,   //The x and y coordinate of where to draw the text.
										&FONT_5_7_1BPP,   //Long font name!
										"Switch is %d",Switch);


			eGFX_Dump(&eGFX_BackBuffer);
}

int main(void)
{

    CLOCK_EnableClock(kCLOCK_InputMux);

    CLOCK_EnableClock(kCLOCK_Iocon);

    CLOCK_EnableClock(kCLOCK_Gpio0);

    CLOCK_EnableClock(kCLOCK_Gpio1);

    CLOCK_EnableClock(kCLOCK_Gpio2);

    CLOCK_EnableClock(kCLOCK_Gpio3);

    CLOCK_EnableClock(kCLOCK_Gpio4);

  	/* USART0 clock */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    /* Initialize the rest */
    BOARD_InitPins();

    BOARD_BootClockRUN();

    BOARD_InitDebugConsole();

	BOARD_InitSDRAM();

	eGFX_InitDriver();

      /*
				This function initializes the WM8904 CODEC and two I2S ports to send and receive audio.
				Read through the comments in the function. (See Audio.c)
	  */

	IOCON_PinMuxSet(IOCON, PORT_INPUT, PIN_INPUT, IOCON_FUNC0 | PULLUP_MODE | IOCON_DIGITAL_EN);

   	InitAudio_CODEC();

   	SystemCoreClockUpdate();

	SysTick_Config(SystemCoreClock/1000);

	Mode = IDLE1;

		while(1)
		{
				/*
						Main Loop
				*/

			WriteToScreen();
			if(DelayTicker>50)				//Poll every 50 ms
			{
				DelayTicker = 0;
				Switch = GPIO->PIN[PORT_INPUT]&(1<<PIN_INPUT);    //Read switch
				if(Switch!=0)
				{
					switch(Mode)
					{
					case(IDLE1):
							Index = 0;
							Mode = REC;
							break;

					case(REC):
							Mode = IDLE2;
							break;

					case(IDLE2):
							PBIndex = 0;
							Mode = PLAYBACK;
							break;

					case(PLAYBACK):
							Mode = IDLE1;
							break;

					}
				}
			}



		}
}




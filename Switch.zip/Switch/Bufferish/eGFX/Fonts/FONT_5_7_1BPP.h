#include "eGFX.h" 

#ifndef _FONT_5_7_1BPP_H
#define _FONT_5_7_1BPP_H

extern const eGFX_Font FONT_5_7_1BPP;

#endif


#include "eGFX.h" 

#ifndef _FONT_3_5_1BPP_H
#define _FONT_3_5_1BPP_H

extern const eGFX_Font FONT_3_5_1BPP;

#endif


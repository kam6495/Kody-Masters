
#include "eGFX.h"


extern 	uint32_t LoopBuffer[960000];
extern	uint8_t eGFX_FrameBuffer1[eGFX_CALCULATE_16BPP_IMAGE_STORAGE_SPACE_SIZE(480,272)];
extern	uint8_t eGFX_FrameBuffer2[eGFX_CALCULATE_16BPP_IMAGE_STORAGE_SPACE_SIZE(480,272)];


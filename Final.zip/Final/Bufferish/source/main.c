
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_emc.h"
#include "pin_mux.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#include "eGFX.h"
#include "eGFX_Driver.h"
#include "FONT_5_7_1BPP.h"
#include "OCR_A_Extended__20px__Bold__SingleBitPerPixelGridFit_1BPP.h"
#include "pin_mux.h"
#include "fsl_iocon.h"
#include "fsl_device_registers.h"
#include "fsl_i2c.h"
#include "fsl_i2s.h"
#include "fsl_wm8904.h"
#include "Audio.h"
#include "SDRAM.h"

#include "fsl_i2c.h"
#include "fsl_ft5406.h"

#include "Sprites_16BPP_565.h"

#include "OCR_A_Extended__20px__Bold__SingleBitPerPixelGridFit_1BPP.h"
#include "Consolas__26px__Regular__AntiAliasGridFit_1BPP.h"
#include "Magneto__26px__Regular__AntiAliasGridFit_16BPP_565.h"

#define REC_BUTTON_START_X	eGFX_PHYSICAL_SCREEN_SIZE_X/2 - 200
#define REC_BUTTON_STOP_X	eGFX_PHYSICAL_SCREEN_SIZE_X/2 - 100
#define MONO_BUTTON_START_X	eGFX_PHYSICAL_SCREEN_SIZE_X/2 - Sprite_16BPP_565_MonoButton.SizeX/2
#define MONO_BUTTON_STOP_X	eGFX_PHYSICAL_SCREEN_SIZE_X/2 + Sprite_16BPP_565_MonoButton.SizeX/2
#define LOOP_BUTTON_START_X	eGFX_PHYSICAL_SCREEN_SIZE_X/2 + 100
#define LOOP_BUTTON_STOP_X	eGFX_PHYSICAL_SCREEN_SIZE_X/2 + 200
#define BUTTON_START_Y	50
#define BUTTON_STOP_Y	BUTTON_START_Y+Sprite_16BPP_565_LoopButton.SizeY

#define SIZE 						960000             //960000 for 30 seconds
#define IDLE						0
#define REC							1
#define PLAYBACK					2

#define PORT_INPUT 					4				//PIO19 is Port 4
#define PIN_INPUT  					4				//PIO19 is Pin 4
#define PULLUP_MODE					(0x2<<4)		//Use internal pull-up resistor

volatile uint32_t NextSampleOut = 0;       //CODEC send through
volatile uint32_t Mono = 0;					//Mono enable variable
volatile uint32_t MonoL = 0;				//variable for mono
volatile uint32_t MonoR = 0;				//variable for mono

volatile uint32_t DelayTicker = 0;         //delay function variable

volatile uint32_t Mode = 0;			// mode variable
volatile uint32_t ScreenMode = 0;	//determines switch action
volatile uint32_t Index = 0;       // Record tracking
volatile uint32_t PBIndex = 0;     // Play back tracking
volatile uint32_t Switch = 0;	   // Foot switch variable




/*
	This union will be used to split 32-bit FIFO data into 2 int16_t samples.
*/
typedef union
{
	uint32_t Data;
	int16_t Channel[2];

}I2S_FIFO_Data_t;

/***
 *      ___ ____  ____    _______  __  ___       _                             _
 *     |_ _|___ \/ ___|  |_   _\ \/ / |_ _|_ __ | |_ ___ _ __ _ __ _   _ _ __ | |_
 *      | |  __) \___ \    | |  \  /   | || '_ \| __/ _ \ '__| '__| | | | '_ \| __|
 *      | | / __/ ___) |   | |  /  \   | || | | | ||  __/ |  | |  | |_| | |_) | |_
 *     |___|_____|____/    |_| /_/\_\ |___|_| |_|\__\___|_|  |_|   \__,_| .__/ \__|
 *                                                                      |_|
 */

void FLEXCOMM6_DriverIRQHandler(void)
{
    if (I2S0->FIFOINTSTAT & I2S_FIFOINTSTAT_TXLVL_MASK)
    {
        	  /*
					NextSampleOut Holds the last value from the I2S RX Interrupt.
				  It is also ready in the "packed" FIFO format
			  */

				if(Mode == PLAYBACK)
					{

					I2S0->FIFOWR = NextSampleOut + LoopBuffer[PBIndex];   //add buffer at offset index
					PBIndex++;

					if(PBIndex == Index)				//loop at end of array
						{
						PBIndex = 0;
						}

					}else{
					PBIndex = 0;
					I2S0->FIFOWR = NextSampleOut;        //direct send through when not in play back
					}



				 /* Clear TX level interrupt flag */
        I2S0->FIFOSTAT = I2S_FIFOSTAT_TXLVL(1U);
		}
}

/***
 *      ___ ____  ____    ____  __  __  ___       _                             _
 *     |_ _|___ \/ ___|  |  _ \ \ \/ / |_ _|_ __ | |_ ___ _ __ _ __ _   _ _ __ | |_
 *      | |  __) \___ \  | |_) | \  /   | || '_ \| __/ _ \ '__| '__| | | | '_ \| __|
 *      | | / __/ ___) | |  _ <  /  \   | || | | | ||  __/ |  | |  | |_| | |_) | |_
 *     |___|_____|____/  |_| \_\/_/\_\ |___|_| |_|\__\___|_|  |_|   \__,_| .__/ \__|
 *                                                                       |_|
 */
void FLEXCOMM7_DriverIRQHandler(void)
{
		register float LeftChannel;
		register float RightChannel;
	    I2S_FIFO_Data_t FIFO_Data;

     /* Clear RX level interrupt flag */
     I2S1->FIFOSTAT = I2S_FIFOSTAT_RXLVL(1U);

	     /*
				Read the Receive FIFO.   Data is packed as two samples in one 32-bit word.  We will immediately store the data
				in a variable that is used is the transmit routine to send incoming data back out.
		 */
	    FIFO_Data.Data = I2S1->FIFORD;
	    NextSampleOut = FIFO_Data.Data; //dump the data back out!

	    if(Mono==1)
	    {
	    	MonoR = (NextSampleOut<<16);
	    	MonoL = (MonoR>>16);
	    	NextSampleOut = MonoL | MonoR;
	    }


			if(Mode == REC)									//Record mode
				{
				LoopBuffer[Index] = NextSampleOut;     //Send data to array
				Index++;

				if(Index == SIZE)
					{                 //End recording at end of array
					Mode = IDLE;
					}

				}


	   LeftChannel = (float)(FIFO_Data.Channel[0])/32768.0f;
	   RightChannel = (float)(FIFO_Data.Channel[1])/32768.0f;


}

void SysTick_Handler()            //millisecond counter
{
	DelayTicker++;
}


int main(void)
{

	int32_t x=10,y=10;		//Some temporary variables for reading the touch screen

	ft5406_handle_t touch_handle;	//For touch screen driver

	touch_event_t touch_event;		//For touch screen driver

	Mode = IDLE;


    CLOCK_EnableClock(kCLOCK_InputMux);

    CLOCK_EnableClock(kCLOCK_Iocon);

    CLOCK_EnableClock(kCLOCK_Gpio0);

    CLOCK_EnableClock(kCLOCK_Gpio1);

    CLOCK_EnableClock(kCLOCK_Gpio2);

    CLOCK_EnableClock(kCLOCK_Gpio3);

    CLOCK_EnableClock(kCLOCK_Gpio4);

  	/* USART0 clock */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    /* Initialize the rest */
    BOARD_InitPins();

    BOARD_BootClockRUN();

    BOARD_InitDebugConsole();

    BOARD_InitSPIFI_ExternalFlash();

	BOARD_InitSDRAM();

	eGFX_InitDriver();

      /*
				This function initializes the WM8904 CODEC and two I2S ports to send and receive audio.
				Read through the comments in the function. (See Audio.c)
	  */

	FT5406_Init(&touch_handle,I2C2);

	IOCON_PinMuxSet(IOCON, PORT_INPUT, PIN_INPUT, IOCON_FUNC0 | PULLUP_MODE | IOCON_DIGITAL_EN);

   	InitAudio_CODEC();

   	SystemCoreClockUpdate();

	SysTick_Config(SystemCoreClock/1000);


		while(1)
		{
				/*
						Main Loop
				*/




			if(DelayTicker>50)				//Poll every 50 ms
			{
				DelayTicker = 0;
				Switch = GPIO->PIN[PORT_INPUT]&(1<<PIN_INPUT);    //Read switch
				if(Switch!=0)
				{
					switch(Mode)
					{
					case(IDLE):
							if(ScreenMode==0)
							{
								Index = 0;
								Mode = REC;
							}else{
								PBIndex = 0;
								Mode = PLAYBACK;
							}
							break;

					case(REC):
							Mode = IDLE;
							break;

					case(PLAYBACK):
							Mode = IDLE;
							break;

					}
				}
			}


			eGFX_ImagePlane_Clear(&eGFX_BackBuffer);


			eGFX_printf_HorizontalCentered_Colored(&eGFX_BackBuffer,
													4,
													&Magneto__26px__Regular__AntiAliasGridFit_16BPP_565 ,
													eGFX_RGB888_TO_RGB565(255,255,255),
													"Looper");


			//read in the x,y coordinate of the the touch sensor if there is a good reading.
		    if (kStatus_Success == FT5406_GetSingleTouch(&touch_handle, &touch_event, &y, &x))
		    {
		    	if (touch_event == kTouch_Contact)
		        {


					if(	 x>=REC_BUTTON_START_X && x<=REC_BUTTON_STOP_X
						&& y>BUTTON_START_Y && y<= BUTTON_STOP_Y)
					{
						if(ScreenMode==0)
						{
							ScreenMode = 1;
						}else{
							ScreenMode = 0;
						}
					}
					if(	 x>=MONO_BUTTON_START_X && x<=MONO_BUTTON_STOP_X
						&& y>BUTTON_START_Y && y<= BUTTON_STOP_Y)
					{
						if(Mono==0)
						{
							Mono = 1;
						}else{
							Mono = 0;
						}
					}
					if(	 x>=LOOP_BUTTON_START_X && x<=LOOP_BUTTON_STOP_X
						&& y>BUTTON_START_Y && y<= BUTTON_STOP_Y)
					{
						if(ScreenMode==0)
						{
							ScreenMode = 1;
						}else{
							ScreenMode = 0;
						}
					}
		         }
		    }


			if(Mono==0)
			{
				eGFX_Blit(&eGFX_BackBuffer,
								MONO_BUTTON_START_X,  //x coordinate of where to put the image
								BUTTON_START_Y,		//y coordinate of where to put the image
								&Sprite_16BPP_565_MonoButton);

			}else{
				eGFX_Blit(&eGFX_BackBuffer,
								MONO_BUTTON_START_X,  //x coordinate of where to put the image
								BUTTON_START_Y,			 //y coordinate of where to put the image
								&Sprite_16BPP_565_MonoButtonON);

			}

			if(ScreenMode==0)
			{
				eGFX_Blit(&eGFX_BackBuffer,
								REC_BUTTON_START_X,  //x coordinate of where to put the image
								BUTTON_START_Y,			 //y coordinate of where to put the image
								&Sprite_16BPP_565_RecordButtonON);
				eGFX_Blit(&eGFX_BackBuffer,
								LOOP_BUTTON_START_X,  //x coordinate of where to put the image
								BUTTON_START_Y,		 //y coordinate of where to put the image
								&Sprite_16BPP_565_LoopButton);

			}else{
				eGFX_Blit(&eGFX_BackBuffer,
								REC_BUTTON_START_X,  //x coordinate of where to put the image
								BUTTON_START_Y,		 //y coordinate of where to put the image
								&Sprite_16BPP_565_RecordButton);
				eGFX_Blit(&eGFX_BackBuffer,
								LOOP_BUTTON_START_X,  //x coordinate of where to put the image
								BUTTON_START_Y,	 //y coordinate of where to put the image
								&Sprite_16BPP_565_LoopButtonON);

			}


			if(Mode==REC)
			{
				eGFX_Blit(&eGFX_BackBuffer,
								REC_BUTTON_START_X,  //x coordinate of where to put the image
								BUTTON_START_Y+100,		 //y coordinate of where to put the image
								&Sprite_16BPP_565_Recording);
			}else if(Mode==PLAYBACK){
				eGFX_Blit(&eGFX_BackBuffer,
								LOOP_BUTTON_START_X,  //x coordinate of where to put the image
								BUTTON_START_Y+100,		 //y coordinate of where to put the image
								&Sprite_16BPP_565_Looping);
			}
			eGFX_Dump(&eGFX_BackBuffer);
		}
}

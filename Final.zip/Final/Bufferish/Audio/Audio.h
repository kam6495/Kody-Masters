#ifndef _AUDIO_H
#define _AUDIO_H

void InitAudio_CODEC(void);
void Init_DMIC(void);


#endif


#include "eGFX.h" 

#ifndef _ARIAL__23PX__REGULAR__SYSTEMDEFAULT_1BPP_H
#define _ARIAL__23PX__REGULAR__SYSTEMDEFAULT_1BPP_H

 extern const eGFX_Font Arial__23px__Regular__SystemDefault_1BPP;

#endif


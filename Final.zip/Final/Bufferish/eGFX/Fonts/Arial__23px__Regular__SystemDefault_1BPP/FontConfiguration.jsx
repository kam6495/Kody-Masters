/*
  Created by JsonExSerializer
  Assembly: lib_eGFX_Tools, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
  Type: lib_eGFX_Tools.FontBuilderConfig
*/
{
    "Ascent":5120, 
    "Descent":1024, 
    "LineSpacing":6656, 
    "SpacesPerTab":4, 
    "InterCharacterSpacing":1, 
    "CombinedOutputName":"Arial__23px__Regular__SystemDefault_1BPP"
}
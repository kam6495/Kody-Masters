/*
  Created by JsonExSerializer
  Assembly: lib_eGFX_Tools, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
  Type: lib_eGFX_Tools.FontBuilderConfig
*/
{
    "Ascent":5888, 
    "Descent":1536, 
    "LineSpacing":7680, 
    "SpacesPerTab":4, 
    "InterCharacterSpacing":1, 
    "CombinedOutputName":"Consolas__26px__Regular__AntiAliasGridFit_1BPP"
}
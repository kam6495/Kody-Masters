#include "eGFX.h" 

#ifndef _CONSOLAS__26PX__REGULAR__ANTIALIASGRIDFIT_1BPP_H
#define _CONSOLAS__26PX__REGULAR__ANTIALIASGRIDFIT_1BPP_H

 extern const eGFX_Font Consolas__26px__Regular__AntiAliasGridFit_1BPP;

#endif


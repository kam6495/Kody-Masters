#include "eGFX.h" 

#ifndef _MAGNETO__26PX__REGULAR__ANTIALIASGRIDFIT_16BPP_565_H
#define _MAGNETO__26PX__REGULAR__ANTIALIASGRIDFIT_16BPP_565_H

__attribute__ ((section ("ExtFlashSection"))) extern const eGFX_Font Magneto__26px__Regular__AntiAliasGridFit_16BPP_565;

#endif


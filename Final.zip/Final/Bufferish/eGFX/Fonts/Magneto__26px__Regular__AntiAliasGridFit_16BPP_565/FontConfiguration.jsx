/*
  Created by JsonExSerializer
  Assembly: lib_eGFX_Tools, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
  Type: lib_eGFX_Tools.FontBuilderConfig
*/
{
    "Ascent":5888, 
    "Descent":1792, 
    "LineSpacing":7936, 
    "SpacesPerTab":4, 
    "InterCharacterSpacing":1, 
    "CombinedOutputName":"Magneto__26px__Regular__AntiAliasGridFit_16BPP_565"
}
#include "eGFX.h" 

#ifndef _FONT_5_7_4BPP_H
#define _FONT_5_7_4BPP_H

extern const eGFX_Font FONT_5_7_4BPP;

#endif


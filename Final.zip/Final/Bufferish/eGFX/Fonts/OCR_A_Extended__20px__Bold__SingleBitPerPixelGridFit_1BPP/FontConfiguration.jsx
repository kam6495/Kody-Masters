/*
  Created by JsonExSerializer
  Assembly: lib_eGFX_Tools, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
  Type: lib_eGFX_Tools.FontBuilderConfig
*/
{
    "Ascent":4352, 
    "Descent":768, 
    "LineSpacing":5120, 
    "SpacesPerTab":4, 
    "InterCharacterSpacing":1, 
    "CombinedOutputName":"OCR_A_Extended__20px__Bold__SingleBitPerPixelGridFit_1BPP"
}
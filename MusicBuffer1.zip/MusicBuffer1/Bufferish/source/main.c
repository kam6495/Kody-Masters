
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_emc.h"
#include "pin_mux.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#include "eGFX.h"
#include "eGFX_Driver.h"
#include "FONT_5_7_1BPP.h"
#include "OCR_A_Extended__20px__Bold__SingleBitPerPixelGridFit_1BPP.h"
#include "pin_mux.h"
#include "fsl_device_registers.h"
#include "fsl_i2c.h"
#include "fsl_i2s.h"
#include "fsl_wm8904.h"
#include "Audio.h"
#include "SDRAM.h"

#define SIZE 						960000             //960000 for 30 seconds
#define IDLE						0
#define REC							1
#define PLAYBACK					2

volatile uint32_t NextSampleOut = 0;       //CODEC send through
volatile uint32_t DelayTicker = 0;         //delay function variable


volatile uint32_t Mode = 0;			// mode variable
volatile uint32_t Index = 0;       // Record tracking
volatile uint32_t PBIndex = 0;     // Play back tracking
volatile uint32_t temp = 0;


/*
	This union will be used to split 32-bit FIFO data into 2 int16_t samples.
*/
typedef union
{
	uint32_t Data;
	int16_t Channel[2];

}I2S_FIFO_Data_t;

/***
 *      ___ ____  ____    _______  __  ___       _                             _
 *     |_ _|___ \/ ___|  |_   _\ \/ / |_ _|_ __ | |_ ___ _ __ _ __ _   _ _ __ | |_
 *      | |  __) \___ \    | |  \  /   | || '_ \| __/ _ \ '__| '__| | | | '_ \| __|
 *      | | / __/ ___) |   | |  /  \   | || | | | ||  __/ |  | |  | |_| | |_) | |_
 *     |___|_____|____/    |_| /_/\_\ |___|_| |_|\__\___|_|  |_|   \__,_| .__/ \__|
 *                                                                      |_|
 */

void FLEXCOMM6_DriverIRQHandler(void)
{
    if (I2S0->FIFOINTSTAT & I2S_FIFOINTSTAT_TXLVL_MASK)
    {
        	  /*
					NextSampleOut Holds the last value from the I2S RX Interrupt.
				  It is also ready in the "packed" FIFO format
			  */

				if(Mode == PLAYBACK)
					{
					I2S0->FIFOWR = NextSampleOut + LoopBuffer[PBIndex];   //add buffer at offset index (first 2 sec are thrown away)
					PBIndex++;

					if(PBIndex == Index)				//loop at end of array
						{
						PBIndex = 0;
						}

					}else{
					PBIndex = 0;
					I2S0->FIFOWR = NextSampleOut;        //direct send through when not in play back
					}



				 /* Clear TX level interrupt flag */
        I2S0->FIFOSTAT = I2S_FIFOSTAT_TXLVL(1U);
		}
}

/***
 *      ___ ____  ____    ____  __  __  ___       _                             _
 *     |_ _|___ \/ ___|  |  _ \ \ \/ / |_ _|_ __ | |_ ___ _ __ _ __ _   _ _ __ | |_
 *      | |  __) \___ \  | |_) | \  /   | || '_ \| __/ _ \ '__| '__| | | | '_ \| __|
 *      | | / __/ ___) | |  _ <  /  \   | || | | | ||  __/ |  | |  | |_| | |_) | |_
 *     |___|_____|____/  |_| \_\/_/\_\ |___|_| |_|\__\___|_|  |_|   \__,_| .__/ \__|
 *                                                                       |_|
 */
void FLEXCOMM7_DriverIRQHandler(void)
{
		register float LeftChannel;
		register float RightChannel;
	    I2S_FIFO_Data_t FIFO_Data;

     /* Clear RX level interrupt flag */
     I2S1->FIFOSTAT = I2S_FIFOSTAT_RXLVL(1U);

	     /*
				Read the Receive FIFO.   Data is packed as two samples in one 32-bit word.  We will immediately store the data
				in a variable that is used is the transmit routine to send incoming data back out.
		 */
	    FIFO_Data.Data = I2S1->FIFORD;
	    NextSampleOut = FIFO_Data.Data; //dump the data back out!


			if(Mode == REC)									//Record mode
				{
				LoopBuffer[Index] = NextSampleOut;     //Send data to array
				Index++;

				if(Index == SIZE)
					{                 //End recording at end of array
					Mode = IDLE;
					}

				}


	   LeftChannel = (float)(FIFO_Data.Channel[0])/32768.0f;
	   RightChannel = (float)(FIFO_Data.Channel[1])/32768.0f;


}

void SysTick_Handler()            //millisecond counter
{
	DelayTicker++;
}

void delay(uint32_t Ticks)      //delay function
{
	DelayTicker = 0;
	while(DelayTicker < Ticks)
	{
	}
}

void WriteToScreen()
{
	eGFX_ImagePlane_Clear(&eGFX_BackBuffer);

			eGFX_printf(&eGFX_BackBuffer,
										20,250,   //The x and y coordinate of where to draw the text.
										&FONT_5_7_1BPP,   //Long font name!
									  "[Hello World!]    Initial Test    Mode is %d",Mode);
			eGFX_printf(&eGFX_BackBuffer,
										20,200,   //The x and y coordinate of where to draw the text.
										&FONT_5_7_1BPP,   //Long font name!
									  "Index is %d",Index);
			eGFX_printf(&eGFX_BackBuffer,
										200,200,   //The x and y coordinate of where to draw the text.
										&FONT_5_7_1BPP,   //Long font name!
									  "PBIndex is %d",PBIndex);

			eGFX_Dump(&eGFX_BackBuffer);
}

int main(void)
{

    CLOCK_EnableClock(kCLOCK_InputMux);

    CLOCK_EnableClock(kCLOCK_Iocon);

    CLOCK_EnableClock(kCLOCK_Gpio0);

    CLOCK_EnableClock(kCLOCK_Gpio1);

  	/* USART0 clock */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    /* Initialize the rest */
    BOARD_InitPins();

    BOARD_BootClockRUN();

    BOARD_InitDebugConsole();

	BOARD_InitSDRAM();

	eGFX_InitDriver();

      /*
				This function initializes the WM8904 CODEC and two I2S ports to send and receive audio.
				Read through the comments in the function. (See Audio.c)
	  */

   	InitAudio_CODEC();

   	SystemCoreClockUpdate();

	SysTick_Config(SystemCoreClock/1000);

		while(1)
		{
				/*
						Main Loop
				*/
			temp = 0;

			Mode = IDLE;
			WriteToScreen();
			delay(3000);

			Index = 0;
			Mode = REC;
			while(temp < 80)
			{
				WriteToScreen();
				delay(500);
				temp++;
			}


			Mode = IDLE;
			WriteToScreen();
			delay(5000);


			Mode = PLAYBACK;
			temp = 0;
			while(temp < 112)
						{
							WriteToScreen();
							delay(500);
							temp++;
						}

			Mode = IDLE;
			WriteToScreen();
			delay(5000);
			temp = 0;

						Index = 0;
						Mode = REC;
						while(temp < 20)
						{
							WriteToScreen();
							delay(500);
							temp++;
						}


						Mode = IDLE;
						WriteToScreen();
						delay(5000);


						Mode = PLAYBACK;
						temp = 0;
						while(temp < 87)
									{
										WriteToScreen();
										delay(500);
										temp++;
									}

						Mode = IDLE;
						WriteToScreen();
						delay(5000);




		}
}




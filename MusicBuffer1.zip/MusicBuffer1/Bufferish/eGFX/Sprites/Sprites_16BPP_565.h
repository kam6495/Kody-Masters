#include "stdint.h" 
#include "eGFX.h" 

#ifndef _SPRITES_16BPP_565_H
#define _SPRITES_16BPP_565_H

////***************************************************************************
////                         Sprite_16BPP_565_badge
////***************************************************************************


extern const eGFX_ImagePlane 	Sprite_16BPP_565_badge;

#endif


#include "eGFX.h" 

#ifndef _OCR_A_EXTENDED__20PX__BOLD__SINGLEBITPERPIXELGRIDFIT_1BPP_H
#define _OCR_A_EXTENDED__20PX__BOLD__SINGLEBITPERPIXELGRIDFIT_1BPP_H

extern const eGFX_Font OCR_A_Extended__20px__Bold__SingleBitPerPixelGridFit_1BPP;

#endif

